#include<stdio.h>
#define max(a,b) ((a) > (b)) ? (a) : (b)
int h,w,vis[1000010];
int fa[1000010],a[1010][1010],ans;
int find(int x)
{
	if(fa[x] == x)
	return x;
	return fa[x] = find(fa[x]);
}
void merge(int x,int y)
{
	int fx = find(x),fy = find(y);
	if(fx != fy)
	fa[fx] = fy;
}
int in(int x,int y)
{
	if(x < 0 || x >= h)
	return 0;
	if(y < 0 || y >= w)
	return 0;
	return 1;
}
int mp(int x,int y)
{
	return x * w + y + 1;
}
int main()
{
	scanf("%d %d",&h,&w);
	for(int i = 0;i < h;i++)
	{
		for(int j = 0;j < w;j++)
		{
			scanf("%d",&a[i][j]);
			fa[mp(i,j)] = mp(i,j);
		}
	}
	for(int i = 0;i < h;i++)
	{
		for(int j = 0;j < w;j++)
		{
			if(a[i][j])
			{
				if(in(i - 1,j) && a[i - 1][j])
				merge(mp(i - 1,j),mp(i,j));
				if(in(i,j - 1) && a[i][j - 1])
				merge(mp(i,j - 1),mp(i,j));
			}
		}
	}
	for(int i = 1;i <= w;i++)
	vis[find(i)] = 1;
	for(int i = 0;i < h;i++)
	{
		for(int j = 0;j < w;j++)
		{
			if(vis[find(mp(i,j))] == 1)
			ans = max(ans,i + 1);
		}
	}
	printf("%d",ans);
	return 0;
}
