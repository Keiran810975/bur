#include<stdio.h>
#include<string.h>
char c[1010];
int main()
{
	while(scanf("%s",c) != EOF)
	{
		int num = 0,pos,l;
		l = strlen(c);
		for(int i = 0;i < l;i++)
		{
			if(c[i] >= 'A' && c[i] <= 'Z')
			c[i] = c[i] - 'A' + 'a'; 
		}
		for(int i = 0;i < l - 3;i++)
		{
			if(c[i] == 'k' && c[i + 1] == 'i' && c[i + 2] == 's' && c[i + 3] == 's')
			num++,pos = i;
		}
		if(num != 0)
		printf("%d %d\n",num,pos);
		else
		printf("0 -1\n");
	}
	return 0;
}
