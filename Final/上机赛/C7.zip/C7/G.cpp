#include<stdio.h>
long long x,y;
long long exgcd(long long a,long long b)
{
	if (!b) 
	{
    	x = 1;
    	y = 0;
    	return a;
  	}
  	long long d = exgcd(b, a % b);
  	long long t = x;
  	x = y;
  	y = t - (a / b) * y;
  	return d;
}
int main()
{
	long long a,b;
	scanf("%lld %lld",&a,&b);
	long long g = exgcd(a,b);
	printf("%lld = %lld*(%lld) + %lld*(%lld)",g,a,x,b,y);
	return 0;
}
