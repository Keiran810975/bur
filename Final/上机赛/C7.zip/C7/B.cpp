#include<stdio.h>
int m,n,s;
long long a[50][50],b[50][50],ans[50][50];
int main()
{
	scanf("%d%d%d",&m,&n,&s);
	for(int i = 1;i <= m;i++)
	{
		for(int j = 1;j <= n;j++)
		scanf("%lld",&a[i][j]);
	}
	for(int i = 1;i <= m;i++)
	{
		for(int j = 1;j <= n;j++)
		scanf("%lld",&b[i][j]);
	}
	for(int i = 1;i <= m;i++)
	{
		for(int j = 1;j <= n;j++)
		{
			if(s == 1)
			ans[i][j] = a[i][j] + b[i][j];
			else
			ans[i][j] = a[i][j] - b[i][j];
		}
	}
	for(int i = 1;i <= m;i++)
	{
		for(int j = 1;j <= n;j++)
		printf("%lld ",ans[i][j]);
		printf("\n");
	}
	return 0;
}
