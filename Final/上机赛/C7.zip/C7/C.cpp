#include<stdio.h>
#include<string.h>
char s[1010],t[1010];
int vis[200],fir[200],las[200];
int main()
{
	gets(s);
	int l = strlen(s);
	for(int i = 0;i < l;i++)
	{
		if(vis[s[i]] == 0)
		fir[s[i]] = i;
		else
		las[s[i]] = i;
		vis[s[i]]++;
	}
	gets(t);
	int ll = strlen(t);
	for(int i = 0;i < ll;i++)
	{
		if(vis[t[i]] == 0)
		printf("-1\n");
		else if(vis[t[i]] == 1)
		printf("%d\n",fir[t[i]]);
		else
		printf("%d\n",las[t[i]] - fir[t[i]]);
	}
	return 0;
}
