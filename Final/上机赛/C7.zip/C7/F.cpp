#include<stdio.h>
char c[110][110];
int ans[110][110];
int dx[8] = {0,0,1,-1,-1,1,1,-1};
int dy[8] = {1,-1,0,0,1,1,-1,-1};
int n,m;
int in(int x,int y)
{
	if(x < 0 || x >= n)
	return 0;
	if(y < 0 || y >= m)
	return 0;
	return 1;
}
int main()
{
	scanf("%d %d",&n,&m);
	for(int i = 0;i < n;i++)
	scanf("%s",c[i]);
	for(int i = 0;i < n;i++)
	{
		for(int j = 0;j < m;j++)
		{
			if(c[i][j] == '0')
			{
				for(int k = 0;k < 8;k++)
				{
					int x = i + dx[k],y = j + dy[k];
					if(in(x,y) && c[x][y] == 'M')
					ans[i][j]++;
				}
			}
		}
	}
	for(int i = 0;i < n;i++)
	{
		for(int j = 0;j < m;j++)
		{
			if(c[i][j] == 'M')
			printf("M");
			else
			printf("%d",ans[i][j]);
		}
		printf("\n");
	}
	return 0;
}
