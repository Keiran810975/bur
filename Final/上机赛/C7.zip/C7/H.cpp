#include<stdio.h>
int B[30][30][30];
int T,x,y,z;
int dfs(int a,int b,int c)
{
	if(a <= 0 || b <= 0 || c <= 0)
	return 1;
	if(a > 25 || b > 25 || c > 25)
	return dfs(25,25,25);
	if(B[a][b][c])
	return B[a][b][c];
	if(a < b && b < c)
	return B[a][b][c] = dfs(a,b,c - 1) + dfs(a,b - 1,c - 1) - dfs(a,b - 1,c);
	else
	return B[a][b][c] = dfs(a - 1,b - 1,c) + dfs(a - 1,b,c) + dfs(a - 1,b,c - 1) - dfs(a - 1,b - 1,c - 1);
}
int main()
{
	scanf("%d",&T);
	B[0][0][0] = 1;
	while(T--)
	{
		scanf("%d%d%d",&x,&y,&z);
		printf("%d\n",dfs(x,y,z));
	}
	return 0;
}
