#include<stdio.h>
#include<string.h>
char c[2010],x1[2010],x2[2010];
int n,l;
int cmp()
{
	for(int i = 0;i < l;i++)
	{
		if(x1[i] > x2[i])
		return 1;
		if(x1[i] < x2[i])
		return -1;
	}
	return 0;
}
void solve()
{
	for(int i = 0;i < l;i++)
	c[l + i] = c[l - i - 1];
	for(int i = 0;i < l;i++)
	x1[i] = c[2 * i],x2[i] = c[2 * i + 1];
	if(cmp() >= 0)
	{
		for(int i = 0;i < l;i++)
		c[i] = x2[i];
	}
	else
	{
		for(int i = 0;i < l;i++)
		c[i] = x1[i];
	}
}
int main()
{
	scanf("%s %d",c,&n);
	l = strlen(c);
	while(n--)
	solve();
	for(int i = 0;i < l;i++)
	printf("%c",c[i]);
}
